---
name: "materials-simulation-skill"
description: "End-to-end materials simulation workflow: Python environment, variable directory tree with run dirs, structures built with GZ_toolkit, reference input script, per-run setup from reffiles, SLURM jobs at a chosen parallelization level, completion checker, CSV summary (OVITO), optional analysis. Includes sub-skills for LAMMPS/MD, SEAKMC, VASP/DFT, SPPARKS and MOOSE, plus SLURM and HPC-install guides. Use whenever the user mentions any of these codes, a simulation campaign or parameter sweep, run dirs, reffiles, building structures (dislocations, vacancies, He clusters, defects), input scripts (in.lammps, input.yaml, INCAR, MOOSE .i), .job files, sbatch/squeue, checking which runs finished, extracting results to CSV, GZ_toolkit, OVITO, or installing simulation software on a cluster, even for one small question about one of these codes."
---

# Materials Simulation Workflow

One skill for the whole life of a simulation campaign: MD (LAMMPS), KMC (SEAKMC, SPPARKS),
DFT (VASP), FEM (MOOSE) and the SLURM / HPC work around them, as sub-skills and references.

```
 0 environment ─▶ 1 dir tree ─▶ 2 structures ─▶ 3 input script ─▶ 4 set up runs
     ─▶ 5 jobs (parallelization level) ─▶ 6 checker ─▶ 7 summarize ─▶ 8 analysis (optional)
                       ▲ user checks ▲             ▲ user checks ▲
```

**Find where the user is.** Someone asking "why does my LAMMPS job say Lost atoms" needs only the
LAMMPS sub-skill, not the whole workflow. Someone saying "I want to study X across T and Y"
starts at step 0. Someone with a finished tree asking for a CSV jumps to step 7. Read
`sim_plan.yaml` in the connected root first if it exists — it records what has been decided.

## Sub-skills and references — read the one you need, when you need it

| Need | File |
|------|------|
| LAMMPS / MD theory, input scripts, potentials, errors, compiling | `software/lammps/GUIDE.md` |
| SEAKMC input.yaml, AV sizing, master–slave / GPU layout (§4.8), troubleshooting | `software/seakmc/GUIDE.md` (+ `references/parameters.md`, `examples.md`) |
| VASP / DFT: INCAR, KPOINTS, POTCAR, POSCAR, calc types | `software/vasp/GUIDE.md` (+ `references/calc-types.md`) |
| SPPARKS (lattice KMC / Potts) | `software/spparks/GUIDE.md` |
| MOOSE (FEM / phase field, HIT input files) | `software/moose/GUIDE.md` |
| Any other code (GROMACS, QE, CP2K, ...) | `software/other.md` |
| Step 0 environment, known machines | `references/environment.md` |
| Step 2 structures with GZ_toolkit | `references/structures.md` |
| Step 5 SLURM details, arrays, dependencies, failures | `references/slurm.md` |
| Step 7 extraction recipes, OVITO | `references/summarize.md` |
| Installing/compiling codes on a cluster, module files | `references/hpc-install.md` |

Workflow scripts are in `scripts/` (standard library only; PyYAML if the plan is YAML).
Templates are in `templates/`.

## Ground rules (apply to every step)

1. **One change per step.** Every structure, every input file derives from a checked reference
   by exactly one modification. Never build a final structure from scratch in one go.
2. **Gates.** Stop and let the user check: after the dir tree is shown, after each reference
   structure, after all final structures, after the reference input script, before submitting.
   Do not roll through a gate because it seems obvious.
3. **The user's files win.** Potentials, job files, reference inputs come from `reffiles/`. If
   something is missing, ask for it. Do **not** download potentials or job templates from the
   internet unless the user says so. Documentation and literature lookups for *how to write*
   input are encouraged — cite the doc page.
4. **Nothing is guessed about the machine.** Paths, partitions, accounts, modules differ between
   machines. Get them from `sim_plan.yaml`, `references/environment.md`, or the user.
   Anything marked **USER** or `<USER: ...>` in this skill is per-user information: ask for
   it, never fill it with a guess or an example value.
5. **`sim_plan.yaml` is the memory.** Record every decision there (template:
   `templates/sim_plan.yaml`). Later steps and later chats read it instead of re-asking.
6. Batch questions into one round. Use AskUserQuestion when choices are discrete.
7. **Name every new directory `N-word`.** This is the user's own convention, so the user and
   the agent share one folder they can both navigate (`cd 3<Tab>`). See "Directory naming"
   below.
8. **Everything the agent makes, a human can re-run.** Saved scripts, one command each,
   readable code. Structure scripts use one method per defect type and one visible call per
   defect. See "Human-runnable work" below.

## Directory naming (N-word) — applies to every directory the agent creates

The user names directories `1-xxx`, `2-xxx`, ... so that `cd 1<Tab>` jumps to one without typing
its name. The agent follows the same pattern, so the human and the AI can work in the same project.

**Before every `mkdir`** (local, over SSH, or on the user's computer):

1. **Look at the parent first** (`ls`, `device_list_dir`). If a directory for the same purpose
   already exists, reuse it. Never create a second one.
2. **Number = the smallest positive number not already used as a prefix** by any entry in that
   parent (directories *and* files). With `1-potentials`, `2-literature`, `4-oldtest`, the new
   dir is `3-...`, not `1-...` and not `5-...`. To list the numbers in use:
   ```bash
   ls -1 PARENT | sed -n 's/^\([0-9][0-9]*\)[-_].*/\1/p' | sort -n
   ```
   If the siblings are zero-padded (`01-`) or use `_`, copy that. Otherwise use plain `N-`.
3. **Word = one short word** (or two joined with `_` or in camelCase) that says what is inside:
   `reffiles`, `workflow`, `screwHeV`, `T300K`, `analysis`. Use only letters, digits, `_` and
   `.`. No spaces, and no `-` inside the word, so the first `-` always ends the number. Keep it
   under about 20 characters.
4. **If the word is not obvious, confirm the name with the user before creating it.** Propose
   one name plus one or two alternatives (AskUserQuestion). The word is obvious when the user
   named the contents, or for the standard dirs below.
5. **Record it.** Directories the workflow relies on go into `sim_plan.yaml`: `reffiles.dir`
   (e.g. `1-reffiles`), `dirs.workflow` (e.g. `2-workflow`), `dirs.analysis`.

**Never rename or renumber existing directories**, the user's or the agent's own, unless the
user asks.

**Standard dirs in a simulation root** (number = next free one): reffiles (e.g. `1-reffiles`),
copied workflow scripts (`2-workflow`), plots and fits in step 8 (e.g. `6-analysis`), and a new
campaign inside a project folder (e.g. `3-screwHeV`, which then becomes ROOT). Wherever this file
says `reffiles/`, `workflow/` or `analysis/`, it means these numbered dirs. Use their real names
in commands (`python 2-workflow/make_tree.py`). The reffiles name comes from `reffiles.dir`.

**Variable dirs of the tree** (step 1) follow the rule too: `3-T300K`, `4-T600K`, and inside
them `1-He1V1`, `2-He2V1`. The number is the next free one in each parent, assigned in the order
of `values`. The bundled `make_tree.py` does not add numbers, because it only formats
`dirname`. To get numbered variable dirs, create the tree yourself and write `manifest.csv` by
hand (columns `relpath`, one per variable holding the plain value, `run`, `run_index`), as
step 1 already allows. All later scripts work from the manifest's `relpath`, so the numbers
need nothing else. Keep the plain values (300, He1V1) in the manifest so placeholders like
`{{T}}` still get plain values. If the folder already holds an unnumbered tree, continue that
style instead of mixing two.

**Checker with a numbered workflow dir:** the bundled `make_checker.py --lang py` writes
`sys.path.insert(0, str(ROOT / "workflow"))` into `checker.py`. Change `"workflow"` to the real
dir name (e.g. `"2-workflow"`) after generating it. `checker.sh` needs no change.

**Exempt:** run dirs (`run1`, `run2`, ...), which are generated in bulk inside a leaf dir and
which the user designed that way. Also exempt are directories a code creates itself (SEAKMC
`SPOut/`, `DataOut/`, `DefectBank/`; VASP NEB `00/ 01/ ...`) and files, which keep fixed
names.

Once there are 10 or more entries, `1<Tab>` matches both `1-...` and `10-...`. Type `1-<Tab>`
instead. Don't start zero-padding a folder that doesn't already pad.


## Human-runnable work: applies to everything the agent sets up or creates

The user will come back to the project without the agent, so every result must be reproducible
by running saved code.

- **No hidden steps.** Every file the agent produces in the project (structures, inputs, job
  files, checkers, summaries, plots) comes from a script saved in the project, in the workflow
  dir or `N-analysis`. Never use an inline `python -c`, an interactive session, or a hand edit
  the script doesn't know about. If the agent fixes something by hand, it puts the fix into
  the script and re-runs it.
- **One command each.** Each script's top docstring gives the exact command to run it from
  ROOT and what it writes. The environment to use is in `sim_plan.yaml: environment`.
  Parameters are named constants at the top of the script, or values in `sim_plan.yaml`,
  never buried in the body.
- **Readable from the code itself, not from comments.** Function and argument names carry the
  meaning, with short docstrings and no walls of comments. A human should see what a structure
  contains by reading the calls.

### Structure scripts (`make_structures.py`)

- **One method per defect type**, e.g. `perfect_crystal(...)`, `add_screw_dislocation(...)`,
  `add_void(s, center, radius)`, `add_vacancy(s, site)`, `add_he_cluster(s, n_he, n_vac, site)`.
  Each takes the structure plus that defect's parameters, makes exactly one change, and returns
  the new structure. The GZ_toolkit calls live inside these methods.
- **Every defect is a visible call** in a short recipe function, one per stage. A structure
  with two voids has two `add_void(...)` lines (the same method called twice), not one
  function that silently does both:
  ```python
  def stage1():
      s = read_ref("ref0_perfect.data")
      s = add_void(s, center=(20.0, 30.0, 20.0), radius=6.0)
      s = add_void(s, center=(60.0, 30.0, 20.0), radius=6.0)
      return write(s, REF / "ref1_twovoids.data")
  ```
  With many defects of one type (e.g. 50 random voids), use one loop over a table defined right
  above it, with its random seed, so the count and positions can still be read on the spot.
- **Per-run structures** (one per run dir) use one `final(row)` recipe with the same visible
  calls. Their arguments come from the manifest row and a readable site table: `SITES` at the
  top of the script, or `<reffiles>/sites.csv`.
- **Stages map 1:1 to the reference chain** (stage0 → ref0, stage1 → ref1, final → run dirs)
  and run one at a time, e.g. `python 2-workflow/make_structures.py --stage 1`, so the user can
  re-create or check any single stage.
- The bundled `templates/make_structures_template.py` predates this rule. Reuse its plumbing (plan loading, `--stage`, `--workers`, `report`), but organize the physics as above: a PARAMETERS block, then DEFECT METHODS (one per type), then RECIPES (one per stage, visible calls).

---

## Step 0 — Environment

Read `references/environment.md`. In short:

- **Where does the work run?** Local machine or SSH to a cluster? Look at the context (device
  bridge folder, an ssh session, Windows paths). If not sure, **ask**.
- **Python**: which interpreter / `.venv` / conda env runs the workflow scripts on *that*
  machine; which local packages (GZ_toolkit, myLAMMPS, SEAKMC_py ...) must go on `sys.path`.
  Check `references/environment.md` "Known machines" first (**USER** section, filled in per
  user). A machine listed there is used without asking. If the machine is not listed, ask
  the user for the paths, and offer to add it to that list.
- Verify before relying on it: run `<python> -c "import sys; print(sys.version)"` and try the
  imports. Write the result into `sim_plan.yaml: environment:`.
- Copy `scripts/*.py` into `ROOT/workflow/` (the connected folder is ROOT). All workflow
  commands below are run from ROOT with the environment's interpreter.

## Step 1 — Directory tree

Ask the user for the tree: which variables, in which nesting order, their values, the directory
naming, and how many runs (and what a run means: statistical repeat with a different seed, or a
different position/configuration). Typical layout:

```
ROOT/                          level 0  (the folder the user connected)
  sim_plan.yaml  manifest.csv  workflow/
  reffiles/                    reference + unchanging files (potentials, ref structures, ref input, .job)
  T300K/                       level 1  variable 1
    rho1e14/                   level 2  variable 2
      He2V1/                   level 3  variable 3
        run1/ run2/ run3/ ...  level 4  run dirs — simulations happen here
  T400K/ ...
```

Put the answers in `sim_plan.yaml: tree:`, then:

```bash
python workflow/make_tree.py --dry-run     # show the tree to the user  ── GATE
python workflow/make_tree.py               # create dirs + manifest.csv
```

`manifest.csv` (one row per run dir with every variable's value) is what all later scripts
iterate over. If a level's values depend on its parent, use the dict form of `values`
(see the script docstring); for anything stranger, write the manifest yourself.

## Step 2 — Structures (Python + GZ_toolkit)

Read `references/structures.md` before writing any structure code. Essentials:

- Always use **GZ_toolkit** (ask for its path if `sim_plan.yaml`/known machines lacks it), and
  read its actual API before calling it — never invent function names.
- **Stage 0: perfect crystal** into `reffiles/ref0_*`. Verify lattice constant (for the
  potential being used), orientation, box size, atom count. **GATE.**
- **Stage 1..k: one change each** (e.g. add a screw dislocation) into `reffiles/ref1_*` ... Each
  stage reads the previous file. **GATE after each.**
- **Final stage**: the per-run change (e.g. a HeV cluster at position i around the dislocation),
  written **directly into each run dir** under the name in `structures.file`. Parallelize over
  run dirs with `--workers` for big trees.
- Start from `templates/make_structures_template.py` → `ROOT/workflow/make_structures.py`.
  Record each stage in `sim_plan.yaml: structures.chain` and mark `checked: true` when the user
  confirms.
- When all final structures exist: report a sample (atoms, types, box), suggest opening a few in
  OVITO, and **GATE** before step 3.

Worked example (He–V binding around a screw dislocation in BCC Fe): ref0 = perfect BCC Fe with
x=[11-2], y=[111], z=[1-10] → user checks → ref1 = ref0 + ½[111] screw dislocation along y →
user checks → final = ref1 + He_nV_m cluster at site i (one site per run dir) → user checks.

## Step 3 — Reference input script

Open the sub-skill for the code (table above) and write — or take the user's — **one** reference
input in `reffiles/`. Check syntax against the official docs for anything not certain
(LAMMPS: docs.lammps.org, VASP: vasp.at/wiki, SPPARKS: spparks.github.io, MOOSE: mooseframework.inl.gov).

Then turn it into a template: replace each value that varies across the tree with a placeholder
named after the variable — `{{T}}`, `{{cluster}}` — plus built-ins `{{SEED}}` (deterministic
per run), `{{RUN}}`, `{{RUN_INDEX}}`, `{{RELPATH}}`, `{{JOBNAME}}`, and any `constants:` from the
plan. Show the user the diff (reference vs template) — **GATE**. Unfilled placeholders are a
hard error later, so typos surface early.

Alternative when the code supports command-line variables (LAMMPS `-var T 300`, SPPARKS `-var`,
MOOSE `Executioner/end_time=10`): keep the input untouched and put `{{T}}` in the job body
instead. Choose whichever the user finds easier to read.

## Step 4 — Set up every run dir

Everything a run needs comes from `reffiles/`: for LAMMPS that is the structure (already in the
run dir from step 2), the input script, the potential file(s), and the `.job` file. If any is
missing from `reffiles/`, ask the user — do not fetch it online unless told to. Fill
`sim_plan.yaml: reffiles:` (`copy`, `link`, `templates`, `job`, `require`), then:

```bash
python workflow/setup_runs.py --dry-run
python workflow/setup_runs.py --workers 32      # parallel over cores
```

For thousands of run dirs, run the setup itself as a one-node SLURM job so each core handles
a slice of run dirs (`--workers $SLURM_CPUS_ON_NODE`). Already-submitted run dirs are skipped
unless `--force`.

## Step 5 — Jobs and parallelization level

**Parallelization level** = the tree level at which one SLURM job is created.

| Level | One job per | Inside the job | Called |
|-------|-------------|----------------|--------|
| run level (e.g. 4) | run dir | the reference `.job` rendered in the run dir | scatter submission (most nodes) |
| e.g. 3 | variable-3 dir | `cd run1; srun ...; cd ..; cd run2; srun ...` in series | level-3 |
| ... | ... | all runs below it, in series | ... |
| 0 | root | every run in the tree | single job |

`--pack k` runs k run dirs concurrently inside an aggregated job (each srun must request its
share of cores). Walltime of aggregated jobs scales from `job.time_per_run`.

The reference job (`reffiles/<name>.job`) supplies the header (`#SBATCH`, modules) and the per-run
body; mark the split with a `# @RUN` line (see `templates/run.job.example`). Before writing
it, confirm partition, account, nodes/cores, walltime, modules — cluster-specific values are
never guessed (`references/slurm.md`).

If the user asks to run and did **not** give a level, **ask** for it (show the job count each
level would produce: count of distinct dirs at that level in `manifest.csv`). Then:

```bash
python workflow/make_jobs.py --level 3            # writes job files + jobs_lv3.txt
python workflow/submit.py --level 3 --dry-run     # show the user  ── GATE
python workflow/submit.py --level 3               # sbatch from each job's dir; IDs -> jobs_submitted.csv
```

Resubmitting only what failed: `make_jobs.py --level L --only-unfinished`, then submit again.

**SEAKMC jobs: master–slave layout.** Parallel SEAKMC uses MPI rank 0 as a master that hands
out saddle-point searches and does no search work itself, so n tasks give n − 1 workers.

- **CPU:** a search can use p cores (`spsearch.force_evaluator.nproc: p`), so (n − 1)/p
  searches run at once. Choose p to divide n − 1 and set `NSearch` to a multiple of
  (n − 1)/p (p = 1: a multiple of n − 1). Easiest is `--ntasks = k·p + 1`, e.g. 33 tasks →
  32 workers → `NSearch` 32 or 64.
- **GPU (critical): the master never gets a GPU.** On a NERSC GPU node (64 CPUs + 4 GPUs),
  request 5 tasks: rank 0 = master on CPU only, ranks 1–4 run Python/LAMMPS on one GPU each.
  `NSearch` a multiple of 4. Don't use `--gpus-per-task=1`; bind with a wrapper that gives
  rank 0 no GPU. Check with `nvidia-smi` in a 1-step test that there are 4 worker processes,
  one per GPU, and none from rank 0.

The full rules, job script and `gpu_bind.sh` wrapper are in `software/seakmc/GUIDE.md` §4.8.

## Step 6 — Checker

Ask the user what "finished" means — e.g. a file exists, `log.lammps` contains
`Total wall time`, a dump has ≥ N lines, no `ERROR`, ≥ N `KMC_*.dat` files. And whether they
want `.sh` or `.py`. Write them into `sim_plan.yaml: checks:` (types in `scripts/checklib.py`), then:

```bash
python workflow/make_checker.py --lang sh    # -> ROOT/checker.sh   (pure bash)
python workflow/make_checker.py --lang py    # -> ROOT/checker.py   (+ --by LEVEL tallies)
./checker.sh        ./checker.sh -u          # all runs / only unfinished; writes status.csv
```

Suggested defaults per code are in each sub-skill's "Workflow integration" section. If nobody
knows what a finished output looks like, look at one finished test run before writing checks.

## Step 7 — Summarize

When the user asks for results, ask which values from which files, and how to reduce them
(last / min / max / mean). Write `sim_plan.yaml: summary.fields`, then:

```bash
python workflow/summarize.py --only-finished --average   # summary.csv + summary_avg.csv
```

CSV by default. Field types: regex, LAMMPS thermo column, CSV column, VASP energy, line/file
counts, OVITO, or custom Python — see `references/summarize.md` and
`templates/ovito_extract_example.py`. Empty cells mean extraction failed; the warnings say why.

## Step 8 — Analysis (optional, on request)

Plots and fits from `summary.csv` (binding energy vs. position, Arrhenius fits of rates vs. T,
averages ± std over runs). Write the analysis as a script in `ROOT/analysis/` so it can be re-run
when more runs finish.

---

## Talking to the user

- Name the step you're on and what the next gate is.
- Show trees, diffs, job counts, and sample structures — not walls of generated files.
- After a gate, record the decision in `sim_plan.yaml` before moving on.