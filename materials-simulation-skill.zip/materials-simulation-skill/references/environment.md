# Step 0 — Working environment

The same workflow runs on very different machines (a Windows laptop, a Linux workstation, an
HPC login node over SSH). Paths to Python, venvs, conda envs and local packages are different on
each. **Never carry paths from one machine to another.**

## 1. Identify the machine

Look at the evidence before asking:

| Evidence | Likely situation |
|----------|------------------|
| Folder connected through the desktop app, paths like `C:\Users\...` | local Windows |
| `/Users/<name>/...` | local macOS |
| A shell where `sbatch`/`squeue` exist, `/home/<user>` or `/scratch/...` | HPC login node (SSH) |
| User says "on the cluster", "on <cluster name>" | SSH to a cluster |

If it is still ambiguous: **ask** — "Is this run on your local machine, or over SSH on a
cluster? If a cluster, which one?"

Quick probes once you have a shell there:

```bash
uname -a 2>/dev/null || ver                 # OS
which sbatch squeue 2>/dev/null             # SLURM present?
module --version 2>&1 | head -1             # Lmod / environment modules?
which python python3 conda 2>/dev/null
```

## 2. Python interpreter and packages

The workflow scripts need only the standard library (+ PyYAML for YAML plans); structure building
needs GZ_toolkit and its deps (usually numpy, maybe ASE/pymatgen); summaries may need `ovito`.

1. Check "Known machines" below. If the machine is listed, use it and confirm with one probe.
2. Otherwise ask the user for:
   - the interpreter: a `.venv` path, a conda env name/prefix, or `module load python/x.y`
   - paths to local packages that are not pip-installed (GZ_toolkit, myLAMMPS, SEAKMC_py, ...)
3. Probe:
   ```bash
   <python> -c "import sys; print(sys.executable, sys.version)"
   <python> -c "import sys; sys.path.insert(0, r'<GZ_toolkit path>'); import <gz package>; print('ok')"
   <python> -c "import yaml, numpy; print('yaml', yaml.__version__)"
   ```
4. Record in `sim_plan.yaml: environment:` (python, python_kind, activate line, modules,
   packages). Offer to add a new machine to the list below so the next chat finds it.

How to call Python on each kind of setup:

| Kind | Call | In a job script |
|------|------|-----------------|
| venv (Linux/mac) | `/path/.venv/bin/python script.py` | `source /path/.venv/bin/activate` |
| venv (Windows) | `C:\path\venv\Scripts\python.exe script.py` | — |
| conda | `conda run -p <prefix> python script.py` or activate first | `source <conda>/etc/profile.d/conda.sh && conda activate <env>` |
| module | `module load python/x.y && python script.py` | same `module load` lines in the header |

Local packages go on `sys.path` at the top of every script that needs them (the structure
template does this from `environment.packages` automatically):

```python
import sys
sys.path.insert(0, r"<path to GZ_toolkit>")
```

### Package re-reading policy (saves effort)

> **USER**: which local packages exist and how stable they are depends on the user. Ask
> once and record it here. Example rows:

| Package | Policy |
|---------|--------|
| <USER: package under active development, e.g. GZ_toolkit> | List its modules and public functions when starting a task, and re-read when an import or attribute fails or the user mentions changes. |
| <USER: stable packages> | Re-read only on ImportError/AttributeError, or if the user says it changed. |
| (no entry) | Treat as under active development. |

## 3. HPC specifics (only when on a cluster)

Ask once, record in `sim_plan.yaml` (used by the reference job file): partition, account,
cores per node, typical walltime limit, the module lines for the simulation code, and the
scratch filesystem where runs should live. If a code is missing on the cluster, go to
`references/hpc-install.md`.

---

## Known machines

> **USER**: this section is filled in by each user. It ships empty on purpose. When the user
> confirms a machine's details, offer to add an entry so later chats can use the machine
> without asking again. An entry holds facts about one machine only. If no entry matches
> the current machine, ask the user; never reuse another machine's paths.

<!-- USER: copy this block once per machine and replace every <USER: ...>
### <USER: short name> — <USER: machine or cluster name>
- OS / access: <USER: windows | macos | linux>, <USER: local | ssh user@host>; scheduler: <USER: slurm | none>
- Recognize it by: <USER: hostname pattern, filesystem paths, e.g. /scratch/...>
- Python: <USER: venv path | conda env name or prefix | module python/x.y>
  - run: <USER: e.g. /path/.venv/bin/python script.py | conda run -p <prefix> python script.py>
  - activate in shells and job scripts: <USER: activate line>
  - where new envs go: <USER: path, if home quota is tight>
- Local packages (put on sys.path): <USER: GZ_toolkit: <path>; other packages: <path>>
- SLURM: partition <USER>, account <USER>, <USER> cores/node, max walltime <USER>
- Code modules: <USER: lammps: module load ...; vasp: module load ...>
- Scratch for runs: <USER: path>
-->
